package modele;

public class Empereur extends Personnage {




    public Empereur() {
        // Appelle le constructeur de la classe mère avec des valeurs par défaut
        super("Empereur", 4, Caracteristiques.EMPEREUR);

    }
    @Override
    public void utiliserPouvoir() {

    }
}

