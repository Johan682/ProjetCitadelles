package modele;

public class Patricien extends Personnage {
    public Patricien() {
        super("Patricien", 4, Caracteristiques.PATRICIEN);
    }

    @Override
    public void utiliserPouvoir() {

    }
}
