package modele;

public class Alchimiste extends Personnage {
    private int orDepense; // Variable pour stocker l'or d�pens� pendant le tour

    public Alchimiste() {
        super("Alchimiste", 6, Caracteristiques.ALCHIMISTE);
    }

    @Override
    public void utiliserPouvoir() {
        // Logique du pouvoir sp�cifique � l'Alchimiste
        // ...

        System.out.println("� la fin de votre tour, tout l'or d�pens� pour b�tir des quartiers vous est rendu.");
    }

    public void ajouterOrDepense(int montant) {
        orDepense += montant;
    }


}
