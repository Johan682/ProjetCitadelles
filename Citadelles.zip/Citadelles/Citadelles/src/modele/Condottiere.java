package modele;

import java.util.Scanner;

public class Condottiere extends Personnage {

    // Constructeur par défaut
    public Condottiere() {
        // Appelle le constructeur de la classe mère avec des valeurs par défaut
        super("Condottiere", 8, Caracteristiques.CONDOTTIERE);
    }

    @Override
    public void utiliserPouvoir() {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Voulez-vous utiliser votre pouvoir de destruction ? (o/n) ");
        char choix = scanner.next().charAt(0);

        if (Character.toLowerCase(choix) == 'o') {
            afficherCitadelles(); // Affiche les citadelles de tous les joueurs

            System.out.print("Quel joueur choisissez-vous ? (0 pour ne rien faire) ");
            if (!scanner.hasNextInt()) {
                System.out.println("invalide. Fin du pouvoir.");
                return;
            }
            int choixJoueur = scanner.nextInt();

            if (choixJoueur >= 0 && choixJoueur <= getPlateau().getNombreJoueurs()) {
                if (choixJoueur == 0) {
                    System.out.println("Vous avez choisi de ne rien faire.");
                    return;
                }

                Joueur joueurChoisi = getPlateau().getJoueur(choixJoueur - 1);

                // Vérifier si le personnage du joueur choisi est de rang 6
                if (joueurChoisi.getPersonnage().getRang() == 5) {
                    System.out.println("Vous ne pouvez pas détruire les quartiers d'un personnage de rang 6.");
                    return;
                }

                // Afficher la liste des quartiers dans la cité du joueur choisi
                System.out.println("Voici la liste des quartiers dans la cité de " + joueurChoisi.getNom() + " :");
                afficherQuartiers(joueurChoisi.getCite());

                System.out.print("Quel quartier choisissez-vous ? ");
                if (!scanner.hasNextInt()) {
                    System.out.println("Choix invalide. Fin du pouvoir.");
                    return;
                }
                int choixQuartier = scanner.nextInt();

                if (choixQuartier >= 1 && choixQuartier <= joueurChoisi.getCite().length && joueurChoisi.getCite()[choixQuartier - 1] != null) {
                    Quartier quartierChoisi = joueurChoisi.getCite()[choixQuartier - 1];
                    int coutDestruction = quartierChoisi.getCout();

                    if (getJoueur().nbPieces() >= coutDestruction) {
                        getJoueur().retirerPieces(coutDestruction);
                        joueurChoisi.retirerQuartierDansCite(quartierChoisi.getNom());

                        System.out.println("Vous avez détruit le quartier " + quartierChoisi.getNom() + " de " + joueurChoisi.getNom() + ".");
                    } else {
                        System.out.println("Votre trésor n'est pas suffisant pour détruire ce quartier.");
                    }
                } else {
                    System.out.println("Choix de quartier invalide. Fin du pouvoir.");
                }
            } else {
                System.out.println("Choix invalide. Aucun quartier n'a été détruit.");
            }
        } else {
            System.out.println("Vous avez choisi de ne rien faire.");
        }
    }

    private void afficherCitadelles() {
        System.out.println("Voici les citadelles des joueurs :");
        for (int i = 0; i < getPlateau().getNombreJoueurs(); i++) {
            Joueur joueur = getPlateau().getJoueur(i);
            System.out.println((i + 1) + " " + joueur.getNom() + " (" + joueur.getPersonnage().getNom()+ ") :");
            afficherQuartiers(joueur.getCite());
        }
    }

    private void afficherQuartiers(Quartier[] citadelle) {
        for (int i = 0; i < citadelle.length; i++) {
            if (citadelle[i] != null) {
                System.out.println((i + 1) + " " + citadelle[i].getNom() + "(coût " + citadelle[i].getCout() + ")");
            }
        }
    }

    @Override
    public void percevoirRessourcesSpecifiques() {
        int compteur = 0;
        if (!getAssassine()) {
            for (Quartier unQuartier : getJoueur().getCite()) {
                if (unQuartier != null && "MILITAIRE".equals(unQuartier.getType())) {
                    compteur++;
                }
            }
            getJoueur().ajouterPieces(compteur);
        }
    }
}
