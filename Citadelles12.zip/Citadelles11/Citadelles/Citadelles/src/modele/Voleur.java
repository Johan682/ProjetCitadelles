package modele;

import controleur.Interaction;

public class Voleur extends Personnage {

    // Constructor
    public Voleur() {
        super("Voleur", 2, Caracteristiques.VOLEUR);
    }

    @Override
    public void utiliserPouvoir() {
        System.out.println("Personnages du jeu : ");

        for (int i = 0; i < getPlateau().getNombrePersonnages(); i++) {
            Personnage personnage = getPlateau().getPersonnage(i);
            System.out.println((i + 1) + " " + personnage.getNom());
        }

        int choix;
        int montantVole = 0;

        do {
            System.out.println("Quel personnage voulez-vous voler ? ");
            choix = Interaction.lireUnEntier();

            if (choix < 1 || choix > getPlateau().getNombrePersonnages()) {
                System.out.println("Personnage invalide. Veuillez choisir un numéro de personnage valide.");
            } else {
                Personnage personnage = getPlateau().getPersonnage(choix - 1);

                if (personnage.estHorsJeu() == true) {
                    System.out.println("Le personnage choisi est écarté du jeu. Fin du pouvoir");
                    break;
                } else if (personnage.getNom().equals("Voleur")) {
                    System.out.println("Le voleur ne peut pas se voler tout seul. Veuillez choisir un autre personnage.");
                } else if (personnage.getRang() == 1) {
                    System.out.println("Vol sur un personnage de rang 1 impossible");
                } else {
                    montantVole = personnage.getJoueur().nbPieces();
                    personnage.setVole();
                    personnage.getJoueur().retirerPieces(montantVole);
                    getJoueur().ajouterPieces(montantVole);

                    System.out.println("Le voleur a volé tout le trésor de " + personnage.getNom() + " (montant : " + montantVole + " pièces)");
                    System.out.println("Le Joueur a maintenant " + getJoueur().nbPieces() + " pièces.");
                }
            }
        } while ((choix < 1 || choix > getPlateau().getNombrePersonnages()) ||
                (choix > 0 && choix <= getPlateau().getNombrePersonnages() && getPlateau().getPersonnage(choix - 1).getNom().equals("Voleur")) ||
                (choix > 0 && choix <= getPlateau().getNombrePersonnages() && getPlateau().getPersonnage(choix - 1).getRang() == 1));
    }
}
