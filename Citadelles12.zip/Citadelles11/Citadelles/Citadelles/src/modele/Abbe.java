package modele;

public class Abbe extends Personnage {
    public Abbe() {
        super("Abb�", 5, Caracteristiques.ABBE);
    }

    @Override
    public void utiliserPouvoir() {

    }
}

