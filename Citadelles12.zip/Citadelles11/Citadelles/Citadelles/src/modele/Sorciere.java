package modele;

import controleur.Interaction;

public class Sorciere extends Personnage {

    // Constructor
    public Sorciere() {
        super("Sorciere", 1, Caracteristiques.SORCIERE);
    }

    @Override
    public void utiliserPouvoir() {
        // Affiche tous les personnages du jeu
        System.out.println("Personnages du jeu : ");

        for (int i = 0; i < getPlateau().getNombrePersonnages(); i++) {
            Personnage personnage = getPlateau().getPersonnage(i);
            System.out.println((i + 1) + " " + personnage.getNom());
        }

        System.out.println("Ensuite, annoncez le personnage que vous ensorcelez.");
        int choix = Interaction.lireUnEntier();

        // V�rifier si le choix est valide
        if (choix < 1 || choix > getPlateau().getNombrePersonnages()) {
            System.out.println("Personnage invalide. Veuillez choisir un num�ro de personnage valide.");
        } else {
            Personnage personnageEnsorcele = getPlateau().getPersonnage(choix - 1);

            // Appeler les m�thodes sp�cifiques au personnage ensorcel�
            personnageEnsorcele.utiliserPouvoir();

            // Reprendre le tour interrompu comme si vous �tiez le personnage ensorcel�
            reprendreTourInterrompu();
        }
    }

    private void percevoirRessources() {
        // Logique pour percevoir les ressources (cartes ou pi�ces d'or)
        // ...

        System.out.println("Vous percevez des ressources.");
    }

    private void reprendreTourInterrompu() {
        System.out.println("Vous reprenez votre tour interrompu.");

        // Logique pour reprendre le tour interrompu
        // ...

        System.out.println("Vous b�n�ficiez des pouvoirs du personnage ensorcel�.");

        // Appeler d'autres m�thodes ou actions n�cessaires
        // ...
    }
}