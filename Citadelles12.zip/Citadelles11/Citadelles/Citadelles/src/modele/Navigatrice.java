package modele;

public class Navigatrice extends Personnage {
    public Navigatrice() {
        super("Navigatrice", 7, Caracteristiques.NAVIGATRICE);
    }

    @Override
    public void utiliserPouvoir() {
        // Recevoir 4 pi�ces d'or de la banque ou piocher 4 cartes
        // ...

        System.out.println("Vous avez re�u 4 pi�ces d'or de la banque ou pioch� 4 cartes.");
    }
}

