package modele;

public class Negociant extends Personnage {
    public Negociant() {
        super("N�gociant", 6, Caracteristiques.NEGOCIANT);
    }

    @Override
    public void utiliserPouvoir() {

    }
}
