package modele;

public class MaitreChanteuse extends Personnage {
    public MaitreChanteuse() {
        super("Ma�tre-Chanteuse", 2, Caracteristiques.MAITRE_CHANTEUSE);
    }

    @Override
    public void utiliserPouvoir() {
        System.out.println("Prenez les 2 jetons Menace et placez-les devant 2 jetons Personnage de votre choix.");
        // Lisez les jetons et appliquez la logique n�cessaire
        // ...

        System.out.println("Vous avez plac� les jetons Menace.");
    }
}

