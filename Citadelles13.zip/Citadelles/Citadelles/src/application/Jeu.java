package application;

import controleur.*;
import modele.*;

import java.awt.*;
import java.util.ArrayList;
import java.util.Random;



public class Jeu {

    private PlateauDeJeu plateauDeJeu;

    private Random generateur;
    private Joueur joueurCourant;

    // Constructor
    public Jeu() {
        plateauDeJeu = new PlateauDeJeu();
        generateur = new Random();
        joueurCourant = null;
    }

    // Public method to start the game
    public void jouer() {
        System.out.println("Bienvenue dans le jeu!");

        // Boucle du menu
        boolean continuer = true;
        while (continuer) {
            // Affichage du menu
            System.out.println("Menu:");
            System.out.println("1. Jouer");
            System.out.println("2. Afficher les règles");
            System.out.println("3. Quitter");

            // Saisie de l'utilisateur
            System.out.print("Choisissez une option (1, 2, ou 3) : ");
            int choix = Interaction.lireUnEntier();

            // Logique en fonction du choix
            switch (choix) {
                case 1:
                    jouerPartie();
                    break;
                case 2:
                    afficherLesRegles();
                    break;
                case 3:
                    continuer = false;
                    System.out.println("Merci d'avoir joué! Au revoir.");
                    break;
                default:
                    System.out.println("Option non valide. Veuillez choisir une option valide.");
                    break;
            }
        }
    }

    private void afficherLesRegles() {
        System.out.println("Les règles du jeu sont les suivantes...");
    }

    private void jouerPartie() {
        initialisation();

        // Boucle de jeu
        while (!partieFinie()) {
            tourDeJeu();
            gestionCouronne();

            reinitialisationPersonnages();
        }

        // Afficher les scores finaux
        calculDesPoints(plateauDeJeu);
    }

    private void initialisation() {
        System.out.println("Initialisation de la partie...");

        // Utiliser la classe Configuration pour configurer le plateau de jeu
        plateauDeJeu = Configuration.configurationDeBase(new Pioche());

        plateauDeJeu.setPioche(Configuration.nouvellePioche());

        // Distribuer deux pièces d'or et quatre cartes Quartier à chaque joueur
        for (int i = 0; i < plateauDeJeu.getNombreJoueurs(); i++) {
            Joueur joueur = plateauDeJeu.getJoueur(i);
            joueur.ajouterPieces(2);  // Distribuer deux pièces d'or
            joueur.ajouterQuartierDansMain(plateauDeJeu.getPioche().piocher());  // Distribuer quatre cartes Quartier
            joueur.ajouterQuartierDansMain(plateauDeJeu.getPioche().piocher());
            joueur.ajouterQuartierDansMain(plateauDeJeu.getPioche().piocher());
            joueur.ajouterQuartierDansMain(plateauDeJeu.getPioche().piocher());
            joueur.ajouterQuartierDansCite(plateauDeJeu.getPioche().piocher());
            joueur.ajouterQuartierDansCite(plateauDeJeu.getPioche().piocher());
            joueur.ajouterQuartierDansCite(plateauDeJeu.getPioche().piocher());
            joueur.ajouterQuartierDansCite(plateauDeJeu.getPioche().piocher());
            joueur.ajouterQuartierDansCite(plateauDeJeu.getPioche().piocher());
            joueur.ajouterQuartierDansCite(plateauDeJeu.getPioche().piocher());

        }

        afficherInformationsJoueurs();
        // Attribuer la couronne à l'un des joueurs pour le premier tour
        int numeroJoueurCouronne = generateur.nextInt(plateauDeJeu.getNombreJoueurs());
        joueurCourant = plateauDeJeu.getJoueur(numeroJoueurCouronne);  // Update the current player
        joueurCourant.setPossedeCouronne(true);
        System.out.println("La couronne est attribuée à " + joueurCourant.getNom() + ".");

        System.out.println("Initialisation terminée!");
    }

    private void afficherInformationsJoueurs() {
        System.out.println("Informations des joueurs :");
        for (int i = 0; i < plateauDeJeu.getNombreJoueurs(); i++) {
            Joueur joueur = plateauDeJeu.getJoueur(i);
            System.out.println(joueur.getNom() + " - Pièces : " + joueur.nbPieces() +
                    ", Cartes en main : " + joueur.nbQuartiersDansMain());

        }
        System.out.println();  // Ligne vide pour la clarté

    }

    private void gestionCouronne() {
        // Trouver le joueur possédant le personnage du Roi
        Joueur joueurPossedantRoi = null;

        for (int i = 0; i < plateauDeJeu.getNombrePersonnages(); i++) {
            Personnage personnage = plateauDeJeu.getPersonnage(i);
            if (personnage != null && personnage.getNom().equals("Roi")) {
                joueurPossedantRoi = personnage.getJoueur();
                break;
            }
        }

        // Si le joueur possède la couronne, mettre à jour le joueurCourant
        if (joueurPossedantRoi != null) {
            joueurCourant = joueurPossedantRoi;
            joueurCourant.setPossedeCouronne(true);
            System.out.println("La couronne est attribuée à " + joueurCourant.getNom() + ".");
        }
    }

    private void reinitialisationPersonnages() {
        for (int i = 0; i < plateauDeJeu.getNombrePersonnages(); i++) {
            Personnage personnage = plateauDeJeu.getPersonnage(i);
            if (personnage != null && personnage.getJoueur() != null) {
                personnage.reinitialiser();

            }
        }
    }

    private boolean partieFinie() {
        // Vérifier si un joueur possède une cité complète
        for (int i = 0; i < plateauDeJeu.getNombreJoueurs(); i++) {
            Joueur joueur = plateauDeJeu.getJoueur(i);

            // Définir le nombre de quartiers requis en fonction du nombre de joueurs
            int quartiersRequis = (plateauDeJeu.getNombreJoueurs() <= 7) ? 7 : 8;

            if (joueur.nbQuartiersDansCite() >= quartiersRequis) {
                System.out.println("La partie est terminée! ");
                return true;
            }
        }

        return false;
    }

    private void tourDeJeu() {
        choixPersonnages();
        traiterActionsPersonnage();
        reinitialiserecarter();
    }

    public void choixPersonnages() {
        System.out.println("Choix des personnages :");

        // Écarter 2 cartes face visible
        ecarterCarteFaceVisible();
        ecarterCarteFaceVisible();

        // Écarter 2 cartes face cachée
        ecarterCarteFaceCachee();
        ecarterCarteFaceCachee();

        // Afficher les personnages restants à choisir
        afficherPersonnagesRestants();

        // Le joueur avec la couronne choisit en premier
        choixPersonnagePourJoueur(joueurCourant);

        // Les autres joueurs choisissent à leur tour
        for (int i = 0; i < plateauDeJeu.getNombreJoueurs(); i++) {
            Joueur joueur = plateauDeJeu.getJoueur(i);
            if (!joueur.equals(joueurCourant)) {
                choixPersonnagePourJoueur(joueur);
            }
        }

        // Réinitialiser l'état horsJeu uniquement pour les personnages assignés à des joueurs
        for (int i = 0; i < plateauDeJeu.getNombrePersonnages(); i++) {
            Personnage personnage = plateauDeJeu.getPersonnage(i);
            if (personnage != null && personnage.getJoueur() != null) {
                personnage.pashorsjeu();
            }
        }
    }




    private void reinitialiserecarter() {
        for (int i = 0; i < plateauDeJeu.getNombrePersonnages(); i++) {
            Personnage personnage = plateauDeJeu.getPersonnage(i);
                personnage.pashorsjeu();

            }
        }


    private void ecarterCarteFaceVisible() {
        // Sélectionner un personnage au hasard
        Personnage personnageCible;

        do {
            personnageCible = plateauDeJeu.getPersonnage(generateur.nextInt(plateauDeJeu.getNombrePersonnages()));
        } while (personnageCible.estHorsJeu() || personnageCible.getNom().equals("Roi"));
        // Répéter tant que le personnage est déjà hors jeu ou est le Roi

        // Écarter le personnage face visible
        personnageCible.mettreHorsJeu();
        System.out.println("Le personnage " + personnageCible.getNom() + " a été écarté du jeu");
    }

    private void ecarterCarteFaceCachee() {
        // Sélectionner un personnage au hasard
        Personnage personnageCible;

        do {
            personnageCible = plateauDeJeu.getPersonnage(generateur.nextInt(plateauDeJeu.getNombrePersonnages()));
        } while (personnageCible.estHorsJeu());  // Répéter tant que le personnage est déjà hors jeu

        // Écarter le personnage face cachée
        personnageCible.mettreHorsJeu();
        System.out.println("Un personnage a été écarté du jeu");
    }

    private void afficherPersonnagesRestants() {
        System.out.println("Personnages restants à choisir :");

        for (int i = 0; i < plateauDeJeu.getNombrePersonnages(); i++) {
            Personnage personnage = plateauDeJeu.getPersonnage(i);
            if (personnage != null && !personnage.estHorsJeu()) {
                System.out.println(personnage.getRang() - 1 + "-" + personnage.getNom());
            }
        }
    }

    private void choixPersonnagePourJoueur(Joueur joueur) {
        System.out.println(joueur.getNom() + ", c'est votre tour de choisir un personnage.");
        afficherPersonnagesRestants();

        // Lire le choix du joueur
        int choix = Interaction.lireUnEntier();

        // Vérifier si le personnage choisi est valide
        while (choix < 0 || choix >= plateauDeJeu.getNombrePersonnages() || plateauDeJeu.getPersonnage(choix).estHorsJeu()) {
            System.out.println("Choix invalide. Veuillez choisir un personnage valide.");
            afficherPersonnagesRestants();
            choix = Interaction.lireUnEntier();
        }

        // Le choix est valide, attribuer le personnage au joueur
        Personnage personnageChoisi = plateauDeJeu.getPersonnage(choix);
        personnageChoisi.setJoueur(joueur);
        System.out.println(joueur.getNom() + " a choisi le personnage " + personnageChoisi.getNom());
        personnageChoisi.mettreHorsJeu();  // Écarter le personnage choisi de la liste affichage
    }




    private void calculDesPoints(PlateauDeJeu plateauDeJeu) {
        for (int i = 0; i < plateauDeJeu.getNombrePersonnages(); i++) {
            Personnage personnage = plateauDeJeu.getPersonnage(i);

            // Étape 1: La somme totale des coûts de construction des quartiers de sa cité
            calculerSommeDesQuartiersDansCite(personnage);

            // Étape 2: 3 points supplémentaires pour cinq types différents
            calculerBonusCinqTypes(personnage);

            // Étape 3: 4 points supplémentaires s'il est le premier joueur à avoir complété sa cité
            estPremierACompleter(plateauDeJeu);
            ajouterPointsPourCiteCompleter(plateauDeJeu);

            // Étape 4: 2 points supplémentaires si sa cité est complète mais qu'il n'a pas été le premier à la compléter
            ajouterPointsPourCiteCompleter(plateauDeJeu);

            // Étape 5: La somme des différents bonus éventuels des Merveilles de sa cité (à implémenter)
            calculerBonusMerveilles();
        }

        // Trouver le joueur avec le score le plus élevé
        Joueur vainqueur = plateauDeJeu.getJoueur(0);
        for (int i = 1; i < plateauDeJeu.getNombreJoueurs(); i++) {
            if (plateauDeJeu.getJoueur(i).getScore() > vainqueur.getScore()) {
                vainqueur = plateauDeJeu.getJoueur(i);
                System.out.println(vainqueur.getScore());
            }
        }

        // Afficher le vainqueur
        System.out.println("Le vainqueur est le joueur : " + vainqueur.getNom());
    }


    private void traiterActionsPersonnage() {
        System.out.println("Traitement des actions des personnages :");

        for (int i = 0; i < plateauDeJeu.getNombrePersonnages(); i++) {
            Personnage personnage = plateauDeJeu.getPersonnage(i);
            if (personnage != null && personnage.getJoueur() != null) {
                System.out.println("C'est au tour de " + personnage.getJoueur().getNom() + " avec le personnage " + personnage.getNom());

                if (!personnage.getAssassine()) {
                    // If the character is not assassinated, the player can perform actions
                    if (personnage.getVole()) {
                        // If the character is a thief, take all the money from the target
                        System.out.println("Gestion Vol");
                    }

                    // Perception of general resources
                    percevoirRessource(personnage);

                    // Perception of specific resources related to the character's power
                    percevoirRessourceSpecifique(personnage);

                    // Check if the player can use the character's power
                    if (peutUtiliserPouvoirPersonnage(personnage)) {
                        // Use the character's power
                        utiliserPouvoirPersonnage(personnage);
                    }

                    // Check if the player can build
                    if (peutConstruire(personnage)) {
                        // Build logic (placeholder)
                        construire(personnage);
                    }
                    if (personnage.getJoueur().quartierPresentDansCite("laboratoire")) {
                        actionLaboratoire(personnage.getJoueur());
                    }


                } else {
                    // If the character is assassinated, do nothing
                    System.out.println("Le personnage " + personnage.getNom() + " est assassiné et ne peut pas agir.");

                    }
                }
            }
    }






    private boolean peutUtiliserPouvoirPersonnage(Personnage personnage) {
        System.out.print("Voulez-vous utiliser le pouvoir du personnage  ? ");
        return Interaction.lireOuiOuNon();
    }

    private boolean peutConstruire(Personnage personnage) {
        System.out.print("Voulez-vous construire  ? ");
        return Interaction.lireOuiOuNon();
    }

    private void construire(Personnage personnage) {
        System.out.println(personnage.getJoueur().getNom() + " peut construire.");

        if (personnage.getNom().equals("Architecte")) {
            System.out.println("Voici vos cartes actuelles : ");
            ArrayList<Quartier> mainJoueur = personnage.getJoueur().getMain();



            int nombreQuartiersConstruits = 0;
            while (nombreQuartiersConstruits < 3) {
                for (int i = 0; i < mainJoueur.size(); i++) {
                    Quartier carte = mainJoueur.get(i);
                    System.out.println((i + 1) + ". " + carte.getNom() + " - Type : " + carte.getType() + " - Pièces : " + carte.getCout());
                }
                System.out.println("Choisissez une carte à construire (1-" + mainJoueur.size() + ") ou 0 pour arrêter : ");
                int choix = Interaction.lireUnEntier();

                if (choix == 0) {
                    break;
                }

                if (choix >= 1 && choix <= mainJoueur.size()) {
                    Quartier quartierChoisi = mainJoueur.get(choix - 1);

                    if (personnage.getJoueur().nbPieces() >= quartierChoisi.getCout()) {
                        if(personnage.getJoueur().quartierPresentDansCite("manufacture") && quartierChoisi.getType().equals("MERVEILLE")) {
                            System.out.println("test");
                            personnage.getJoueur().ajouterPieces(1);
                        }
                        personnage.getJoueur().ajouterQuartierDansCite(quartierChoisi);
                        personnage.getJoueur().getMain().remove(quartierChoisi);
                        personnage.getJoueur().retirerPieces(quartierChoisi.getCout());

                        // Afficher la cité mise à jour
                        System.out.println("Cité de " + personnage.getJoueur().getNom() + " :");
                        afficherQuartiers(personnage.getJoueur().getCite());

                        System.out.println("Construction réussie.");

                        nombreQuartiersConstruits++;
                    } else {
                        System.out.println("Construction échouée. Vous n'avez pas assez de pièces.");
                    }
                } else {
                    System.out.println("Choix invalide. Veuillez choisir une carte valide.");
                }
            }
        } else {
            System.out.println("Voici vos cartes actuelles : ");
            ArrayList<Quartier> mainJoueur = personnage.getJoueur().getMain();

            for (int i = 0; i < mainJoueur.size(); i++) {
                Quartier carte = mainJoueur.get(i);
                System.out.println((i + 1) + ". " + carte.getNom() + " - Type : " + carte.getType() + " - Pièces : " + carte.getCout());
            }

            System.out.println("Choisissez une carte à construire (1-" + mainJoueur.size() + ") : ");
            int choix = Interaction.lireUnEntier();

            if (choix >= 1 && choix <= mainJoueur.size()) {
                Quartier quartierChoisi = mainJoueur.get(choix - 1);

                if (personnage.getJoueur().nbPieces() >= quartierChoisi.getCout()) {
                    if(personnage.getJoueur().quartierPresentDansCite("manufacture") && quartierChoisi.getType().equals("MERVEILLE")) {
                        System.out.println("test");
                        personnage.getJoueur().ajouterPieces(1);
                    }
                    personnage.getJoueur().ajouterQuartierDansCite(quartierChoisi);
                    personnage.getJoueur().getMain().remove(quartierChoisi);
                    personnage.getJoueur().retirerPieces(quartierChoisi.getCout());

                    // Afficher la cité mise à jour
                    System.out.println("Cité de " + personnage.getJoueur().getNom() + " :");
                    afficherQuartiers(personnage.getJoueur().getCite());

                    System.out.println("Construction réussie.");
                } else {
                    System.out.println("Construction échouée. Vous n'avez pas assez de pièces.");
                }
            } else {
                System.out.println("Choix invalide. Veuillez choisir une carte valide.");
            }
        }
    }


    private void percevoirRessource(Personnage personnage) {
        System.out.println("Perception des ressources :");

        System.out.println("1. Percevoir deux pièces d'or");
        System.out.println("2. Piocher deux cartes Quartier");

        int choix = Interaction.lireUnEntier();

        switch (choix) {
            case 1:
                personnage.getJoueur().ajouterPieces(+2);  // Ajouter deux pièces d'or
                System.out.println("2 pièces ajoutées à " +personnage.getJoueur().getNom());
                break;
            case 2:
                Quartier carte1 = plateauDeJeu.getPioche().piocher();
                Quartier carte2 = plateauDeJeu.getPioche().piocher();

                System.out.println(personnage.getJoueur().getNom() + ", vous avez pioché les cartes :");
                System.out.println("1. " + carte1.getNom());
                System.out.println("2. " + carte2.getNom());
                if(personnage.getJoueur().quartierPresentDansCite("bibliothèque")) {
                    System.out.println("biliothèque présente dans cité (activation du pouvoir)");
                } else if (personnage.getJoueur().quartierPresentDansCite("forge")) {
                    System.out.println("Forge présente : voulez vous payez deux pièces pour piocher une carte en plus? ");

                    boolean choixCarte = Interaction.lireOuiOuNon();
                    if(choixCarte == true) {
                        Quartier carte3 = plateauDeJeu.getPioche().piocher();
                        System.out.println("3. " + carte3.getNom());
                        personnage.getJoueur().ajouterQuartierDansMain(carte1);
                        personnage.getJoueur().ajouterQuartierDansMain(carte2);
                        personnage.getJoueur().ajouterQuartierDansMain(carte3);
                        personnage.getJoueur().retirerPieces(2);
                    }
                    else {
                        System.out.println("Choisissez une carte à conserver (1 ou 2) :");
                        int choixC = Interaction.lireUnEntier();

                        // Garder la carte choisie et défausser l'autre
                        if (choixC == 1) {
                            personnage.getJoueur().ajouterQuartierDansMain(carte1);
                            plateauDeJeu.getPioche().ajouter(carte2);
                            System.out.println("carte " + carte2.getNom() + " défaussée avec succès");
                            break;
                        } else if (choixC == 2) {
                            personnage.getJoueur().ajouterQuartierDansMain(carte2);
                            plateauDeJeu.getPioche().ajouter(carte1);
                            System.out.println("carte " + carte1.getNom() + " défaussée avec succès");
                        }

                    }
                } else {

                    System.out.println("Choisissez une carte à conserver (1 ou 2) :");
                    int choixCarte = Interaction.lireUnEntier();

                    // Garder la carte choisie et défausser l'autre
                    if (choixCarte == 1) {
                        personnage.getJoueur().ajouterQuartierDansMain(carte1);
                        plateauDeJeu.getPioche().ajouter(carte2);
                        System.out.println("carte " + carte2.getNom() + " défaussée avec succès");
                        break;
                    } else if (choixCarte == 2) {
                        personnage.getJoueur().ajouterQuartierDansMain(carte2);
                        plateauDeJeu.getPioche().ajouter(carte1);
                        System.out.println("carte " + carte1.getNom() + " défaussée avec succès");
                    }
                }
                break;
            default:
                System.out.println("Option non valide. Vous percevrez deux pièces d'or par défaut.");
                personnage.getJoueur().ajouterPieces(2);
                break;
        }
    }

    private void percevoirRessourceSpecifique(Personnage personnage) {
        personnage.percevoirRessourcesSpecifiques();
        if(personnage.getJoueur().quartierPresentDansCite("école de magie")) {
            System.out.println("école de magie dans votre cité. Choisissez un type pour recevoir des revenus");



        }

    }

    private void utiliserPouvoirPersonnage(Personnage personnage) {

        personnage.utiliserPouvoir();

        System.out.println(personnage.getJoueur().getNom() + " utilise le pouvoir de " + personnage.getNom() + ".");
    }


    private void afficherQuartiers(Quartier[] citadelle) {
        for (int i = 0; i < citadelle.length; i++) {
            if (citadelle[i] != null) {
                System.out.println((i + 1) + " " + citadelle[i].getNom() + "(coût " + citadelle[i].getCout() + ")");
            }
        }
    }

    private void actionLaboratoire(Joueur joueur) {
        System.out.println("Pouvoir du laboratoire : Voulez-vous défausser une carte pour gagner deux pièces?");
        boolean choix = Interaction.lireOuiOuNon();

        if (choix) {
            System.out.println("Voici vos cartes actuelles : ");
            ArrayList<Quartier> mainJoueur = joueur.getMain();

            for (int j = 0; j < mainJoueur.size(); j++) {
                Quartier carte = mainJoueur.get(j);
                System.out.println((j + 1) + ". " + carte.getNom() + " - Type : " + carte.getType() + " - Pièces : " + carte.getCout());
            }

            System.out.println("Choisissez une carte à défausser (1-" + mainJoueur.size() + ") : ");
            int choixCarte = Interaction.lireUnEntier();

            if (choixCarte >= 1 && choixCarte <= mainJoueur.size()) {
                Quartier carteDefaussee = mainJoueur.remove(choixCarte - 1);
                joueur.ajouterPieces(2);

                System.out.println("Carte " + carteDefaussee.getNom() + " défaussée avec succès. Vous avez gagné deux pièces.");
            } else {
                System.out.println("Choix invalide. Aucune carte défaussée.");
            }
        }

    }
    private void calculerSommeDesQuartiersDansCite(Personnage personnage) {
        if (personnage.getJoueur() != null) {
            int somme = 0;
            for (Quartier quartier : personnage.getJoueur().getCite()) {
                somme += quartier.getCout();
            }
            personnage.getJoueur().setScore(somme);
        }
    }


    private void calculerBonusCinqTypes(Personnage personnage) {
        if (personnage.getJoueur() != null && personnage.getJoueur().getCite() != null) {
            ArrayList<String> typeListe = new ArrayList<>();
            for (Quartier quartier : personnage.getJoueur().getCite()) {
                typeListe.add(quartier.getType());
            }
            if (typeListe.contains("RELIGIEUX") && typeListe.contains("MILITAIRE") &&
                    typeListe.contains("NOBLE") && typeListe.contains("COMMERCANT") &&
                    typeListe.contains("MERVEILLE")) {
                personnage.getJoueur().setScore(3);
            }
        }
    }



    private void estPremierACompleter(PlateauDeJeu plateauDeJeu) {
        for (int i = 0; i < plateauDeJeu.getNombrePersonnages(); i++) {
            if (plateauDeJeu.getPersonnage(i).getJoueur() != null &&
                    plateauDeJeu.getPersonnage(i).getJoueur().nbQuartiersDansCite() >= 7) {
                plateauDeJeu.setPremierAvoirFinir(plateauDeJeu.getPersonnage(i));
                break;
            }
        }
    }

    private void ajouterPointsPourCiteCompleter(PlateauDeJeu plateauDeJeu) {
        for (int i = 0; i < plateauDeJeu.getNombrePersonnages(); i++) {
            Personnage personnage = plateauDeJeu.getPersonnage(i);

            if (personnage != null && personnage.getJoueur() != null) {
                Joueur joueur = personnage.getJoueur();

                if (personnage.equals(plateauDeJeu.getPremierAvoirFinir())) {
                    joueur.setScore(joueur.getScore() + 4);
                }

                if (joueur.nbQuartiersDansCite() >= 7 && !personnage.equals(plateauDeJeu.getPremierAvoirFinir())) {
                    joueur.setScore(joueur.getScore() + 2);
                }
            }
        }
    }




    private void calculerBonusMerveilles() {

    }

}
