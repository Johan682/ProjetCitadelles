package application;
import modele.*;
import controleur.*;


public class Configuration {

    private static Quartier temple = new Quartier("temple",Quartier.TYPE_QUARTIERS[0],1);
    private static Quartier eglise = new Quartier("église",Quartier.TYPE_QUARTIERS[0],2);
    private static Quartier monastere = new Quartier("monastère",Quartier.TYPE_QUARTIERS[0],3);
    private static Quartier cathedrale = new Quartier("cathédrale",Quartier.TYPE_QUARTIERS[0],5);

    private static Quartier tourdeguet  = new Quartier("tour de guet",Quartier.TYPE_QUARTIERS[1],1);
    private static Quartier prison  = new Quartier("prison",Quartier.TYPE_QUARTIERS[1],2);
    private static Quartier caserne  = new Quartier("caserne",Quartier.TYPE_QUARTIERS[1],3);
    private static Quartier forteresse  = new Quartier("forteresse",Quartier.TYPE_QUARTIERS[1],5);

    private static Quartier manoir  = new Quartier("manoir",Quartier.TYPE_QUARTIERS[2],3);
    private static Quartier chateau  = new Quartier("château",Quartier.TYPE_QUARTIERS[2],4);
    private static Quartier palais  = new Quartier("palais",Quartier.TYPE_QUARTIERS[2],5);


    private static Quartier taverne  = new Quartier("taverne",Quartier.TYPE_QUARTIERS[3],1);
    private static Quartier echoppe  = new Quartier("echoppe",Quartier.TYPE_QUARTIERS[3],2);
    private static Quartier marche  = new Quartier("marché",Quartier.TYPE_QUARTIERS[3],2);
    private static Quartier comptoir  = new Quartier("comptoir",Quartier.TYPE_QUARTIERS[3],3);
    private static Quartier port  = new Quartier("port",Quartier.TYPE_QUARTIERS[3],4);
    private static Quartier hdv  = new Quartier("hôtel de ville",Quartier.TYPE_QUARTIERS[3],5);

    private static Quartier bibliotheque = new Quartier("bibliothèque",Quartier.TYPE_QUARTIERS[4],6);
    private static Quartier forge = new Quartier("forge",Quartier.TYPE_QUARTIERS[4],5);
    private static Quartier carriere = new Quartier("carrière",Quartier.TYPE_QUARTIERS[4],5);
    private static Quartier laboratoire = new Quartier("laboratoire",Quartier.TYPE_QUARTIERS[4],5);
    private static Quartier courDesMiracles = new Quartier("cour des miracles",Quartier.TYPE_QUARTIERS[4],2);
    private static Quartier manufacture = new Quartier("manufacture",Quartier.TYPE_QUARTIERS[4],5);
    private static Quartier donjon = new Quartier("donjon",Quartier.TYPE_QUARTIERS[4],3);
    private static Quartier salleDesCartes = new Quartier("salle des cartes",Quartier.TYPE_QUARTIERS[4],5);
    private static Quartier dracoport = new Quartier("dracoport",Quartier.TYPE_QUARTIERS[4],6);
    private static Quartier statueEquestre = new Quartier("statue équestre",Quartier.TYPE_QUARTIERS[4],3);
    private static Quartier ecoleDeMagie = new Quartier("école de magie",Quartier.TYPE_QUARTIERS[4],6);
    private static Quartier tresorImperial = new Quartier("trésor Impérial",Quartier.TYPE_QUARTIERS[4],5);
    private static Quartier fontaineAuxSouhaits = new Quartier("fontaine aux souhaits",Quartier.TYPE_QUARTIERS[4],5);
    private static Quartier tripot = new Quartier("tripot",Quartier.TYPE_QUARTIERS[4],6);

    public static Pioche nouvellePioche() {
        Pioche p = new Pioche();

        p.ajouter(bibliotheque);
        p.ajouter(carriere);
        p.ajouter(courDesMiracles);
        p.ajouter(donjon);
        p.ajouter(dracoport);
        p.ajouter(ecoleDeMagie);
        p.ajouter(fontaineAuxSouhaits);
        p.ajouter(forge);
        p.ajouter(laboratoire);
        p.ajouter(manufacture);
        p.ajouter(salleDesCartes);
        p.ajouter(statueEquestre);
        p.ajouter(tresorImperial);
        p.ajouter(tripot);

        for (int i = 0; i < 2; i++) {
            p.ajouter(cathedrale);
            p.ajouter(forteresse);
            p.ajouter(hdv);
        }

        for (int i = 0; i < 3; i++) {
        p.ajouter(temple);
        p.ajouter(eglise);
        p.ajouter(monastere);
        p.ajouter(tourdeguet);
        p.ajouter(prison);
        p.ajouter(caserne);
        p.ajouter(palais);
        p.ajouter(echoppe);
        p.ajouter(comptoir);
        p.ajouter(port); }

        for (int i = 0; i < 4; i++) {
            p.ajouter(chateau);
            p.ajouter(marche);
        }

        for (int i = 0; i < 5; i++) {
            p.ajouter(manoir);
            p.ajouter(taverne);
        }
        p.melanger();
        return p ;
    }

    public static PlateauDeJeu configurationDeBase(Pioche p) {
        PlateauDeJeu plateau = new PlateauDeJeu();
        Joueur joueur1 = new Joueur("Johan");
        plateau.ajouterJoueur(joueur1);

        Joueur joueur2 = new Joueur("Dolara");
        plateau.ajouterJoueur(joueur2);

        Joueur joueur3 = new Joueur("Farel");
        plateau.ajouterJoueur(joueur3);

        Joueur joueur4 = new Joueur("Franck");
        plateau.ajouterJoueur(joueur4);

        Assassin assassin = new Assassin();
        plateau.ajouterPersonnage(assassin);

        Voleur voleur = new Voleur();
        plateau.ajouterPersonnage(voleur);

        Magicienne magicienne = new Magicienne();
        plateau.ajouterPersonnage(magicienne);

        Roi roi = new Roi();
        plateau.ajouterPersonnage(roi);

        Eveque eveque = new Eveque();
        plateau.ajouterPersonnage(eveque);

        Marchande marchande = new Marchande();
        plateau.ajouterPersonnage(marchande);

        Architecte architecte = new Architecte();
        plateau.ajouterPersonnage(architecte);

        Condottiere condottiere = new Condottiere();
        plateau.ajouterPersonnage(condottiere);


        return plateau ;

    }
}
