package modele;

import java.util.Scanner;

public class Eveque extends Personnage {

    // Constructeur par défaut
    public Eveque() {
        // Appelle le constructeur de la classe mère avec des valeurs par défaut
        super("Eveque", 5, Caracteristiques.EVEQUE);
    }

    @Override
    public void utiliserPouvoir() {

    }

    @Override
    public void percevoirRessourcesSpecifiques() {
        if (getAssassine() != true) {
            int compteur = 0;
                for (Quartier unQuartier : getJoueur().getCite()) {
                    if (unQuartier != null && unQuartier.getType().equals("RELIGIEUX")) {
                        compteur++;
                    }
                }
                getJoueur().ajouterPieces(compteur);
            }
        }
    }

