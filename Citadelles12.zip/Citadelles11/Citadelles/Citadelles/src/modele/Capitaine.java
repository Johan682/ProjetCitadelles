package modele;

public class Capitaine extends Personnage {
    public Capitaine() {
        super("Capitaine", 8, Caracteristiques.CAPITAINE);
    }

    @Override
    public void utiliserPouvoir() {

    }
}

