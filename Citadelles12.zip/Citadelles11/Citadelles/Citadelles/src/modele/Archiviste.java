package modele;

public class Archiviste extends Personnage {
    public Archiviste() {
        super("Archiviste", 7, Caracteristiques.ARCHIVISTE);
    }

    @Override
    public void utiliserPouvoir() {
        // Piocher 7 cartes Quartier, choisir-en une � ajouter � la main et remettre les autres dans la pioche
        // ...

        // Logique pour b�tir jusqu'� 2 quartiers pendant le tour
        // ...

        System.out.println("Vous avez pioch� 7 cartes Quartier, choisi-en une � ajouter � votre main et vous pouvez b�tir jusqu'� 2 quartiers pendant votre tour.");
    }
}

