package modele;

import controleur.Interaction;

public class Sorcier extends Personnage {
    public Sorcier() {
        super("Sorcier", 3, Caracteristiques.SORCIER);
    }

    @Override
    public void utiliserPouvoir() {
        System.out.println("Regardez la main de cartes d'un autre joueur et choisissez-en une.");
        // Lisez le joueur cibl�
        int joueurCible = Interaction.lireUnEntier();

        // Impl�mentez la logique pour regarder la main du joueur cibl� et choisir une carte
        // ...

        System.out.println("Vous avez utilis� le pouvoir du Sorcier.");
    }
}
