package modele;

import application.Configuration;
import controleur.Interaction;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Random;

/*public class Jeu {

    private PlateauDeJeu plateauDeJeu;
    private int numeroConfiguration;
    private Random generateur;
    private Joueur[] joueurs;

    public Jeu() {
        plateauDeJeu = new PlateauDeJeu();
        numeroConfiguration = 0;
        generateur = new Random();
    }

    public void jouer() {
        affichageBienvenue();
        int choix;
        do {
            affichageMenu();
            choix = lireChoix();
            switch (choix) {
                case 1:
                    jouerPartie();
                    break;
                case 2:
                    afficherLesRegles();
                    break;
                case 3:
                    // Ajoutez ici le code pour quitter le jeu si nécessaire
                    break;
                default:
                    System.out.println("Choix invalide. Veuillez choisir à nouveau.");
            }
        } while (choix != 3);
    }

    private void affichageBienvenue() {
        System.out.println("Bienvenue dans Citadelles!");
    }

    private void affichageMenu() {
        System.out.println("Menu:");
        System.out.println("1. Jouer une partie");
        System.out.println("2. Afficher les règles");
        System.out.println("3. Quitter");
    }

    private int lireChoix() {
        System.out.print("Choix = ? ");
        return Interaction.lireUnEntier();
    }

    private void jouerPartie() {
        initialisation();
        while (!partieFinie()) {
            tourDeJeu();
            gestionCouronne();
            reinitialisationPersonnages();
        }
        calculDesPoints();
    }

    private void afficherLesRegles() {
        System.out.println("Voici les règles du jeu Citadelles (implémentation à venir).");
    }


    private void initialisation() {
        // Initialisation de la pioche et du plateau
        Pioche pioche1 = Configuration.nouvellePioche();
        PlateauDeJeu plateauDeJeu1 = Configuration.configurationDeBase(pioche1);

        // Initialisation des joueurs
        joueurs[0] = new Joueur( "Utilisateur");
        joueurs[1] = new Joueur( "IA1");
        joueurs[2] = new Joueur( "IA2");
        joueurs[3] = new Joueur( "IA3");
        joueurs = new Joueur[4];
        for (int i = 0; i < 4; i++) {
            // Distribution de deux pièces d'or
            joueurs[i].ajouterPieces(2);

            // Distribution de quatre cartes Quartier
            for (Joueur joueur : joueurs){
                pioche1.piocher();

            }
        }

        // Attribuer la couronne au premier joueur pour le premier tour
        joueurs[0].recevoirCouronne();
    }

    private void choixPersonnages() {
        plateauDeJeu.setPersonnagesVisible(Configuration.piocherPersonnages(2));
        plateauDeJeu.setPersonnageCache(Configuration.piocherPersonnages(1).get(0));

        int joueurCouronne = 0;

        System.out.println("Choix des personnages :");
        plateauDeJeu.afficherCartesRestantes();
        plateauDeJeu.afficherCartesEcartees();

        System.out.println("Vous avez la couronne !");
        System.out.println("1. Assassin\n3. Magicienne\n4. Roi\n6. Marchande\n8. Condottiere");

        // Continue the implementation for character selection by the user
    }

    private void tourDeJeu() {
        choixPersonnages();
        for (int i = 1; i <= 8; i++) {
            for (Joueur joueur : joueurs) {
                if (joueur.aPersonnage(i)) {
                    appelerPersonnage(joueur, i);
                    if (!joueur.estAssassine() && !joueur.estVole()) {
                        percevoirRessource(joueur);
                        if (joueur.utiliserPouvoir()) {
                            if (joueur.aPersonnage(7)) {
                                construire(joueur);
                            }
                        }
                    }
                }
            }
        }
    }


    private void percevoirRessource(Joueur joueur) {
        System.out.println("Choix des ressources pour " + joueur.getNom() + " :");
        System.out.println("1. Prendre deux pièces d'or");
        System.out.println("2. Piocher deux cartes quartier");

        int choix = Interaction.lireUnEntier(1, 3);
        switch (choix) {
            case 1:
                joueur.recevoirPiecesOr(2);
                break;
            case 2:
                ArrayList<Quartier> cartesPiochees = Configuration.piocherCartes(2);
                System.out.println("Cartes piochées : " + cartesPiochees);
                System.out.println("Voulez-vous garder une carte dans votre main ? (oui/non)");
                if (Interaction.lireOuiOuNon()) {
                    // Handle the choice to keep a card in hand
                } else {
                    // Handle the case where the player discards the second card
                }
                break;
            default:
                // Handle the default case
        }
    }

    private void appelerPersonnage(Joueur joueur, int numeroPersonnage) {
        System.out.println(joueur.getNom() + " appelle le personnage " + numeroPersonnage);
        // Implement specific logic for calling the character based on your game
    }

    private void construire(Joueur joueur) {
        // Implement specific logic for construction based on your game
    }

    public void gestionCouronne() {
        Joueur joueurRoi = null;  // Variable pour stocker le joueur ayant le personnage du Roi

        // Parcourir les joueurs pour trouver celui qui a le personnage du Roi
        for (Joueur joueur : listeJoueurs) {
            if (joueur.aPersonnage(Personnage.ROI)) {
                joueurRoi = joueur;
                break;
            }
        }

        // Si le personnage du Roi a été choisi pendant le tour, attribuer la couronne
        if (joueurRoi != null) {
            this.couronne = joueurRoi;
        }

        // Afficher le joueur qui a la couronne (ou un message si le Roi n'a pas été choisi)
        if (couronne != null) {
            System.out.println("Le joueur " + couronne.getNom() + " a la couronne.");
        } else {
            System.out.println("Le personnage du Roi n'a pas été choisi ce tour. La couronne reste au même joueur.");
        }
    }


    public void reinitialisationPersonnages() {
        // Réinitialiser chaque personnage en fin de tour
        for (Personnage personnage : listePersonnages) {
            // Réinitialiser l'état du personnage
            personnage.reinitialiser();

            // Si le personnage est l'Architecte, réinitialiser le compteur de constructions
            if (personnage instanceof Architecte) {
                ((Architecte) personnage).reinitialiserCompteurConstructions();
            }
        }
    }


    public boolean partieFinie() {
        // Vérifiez si l'un des joueurs possède une cité complète
        for (Joueur joueur : listeJoueurs) {
            if (joueur.possedeCiteComplete()) {
                return true; // La partie est terminée
            }
        }
        return false; // Aucun joueur n'a de cité complète, la partie continue
    }


    public void calculDesPoints() {
        // Pour chaque joueur, afficher son score
        for (Joueur joueur : listeJoueurs) {
            System.out.println("Le score du Joueur " + joueur.getNom() + " est : " + joueur.getScore());
        }
    }

}*/
