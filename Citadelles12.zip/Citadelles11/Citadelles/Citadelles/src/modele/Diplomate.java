package modele;

public class Diplomate extends Personnage {
    public Diplomate() {
        super("Diplomate", 8, Caracteristiques.DIPLOMATE);
    }

    @Override
    public void utiliserPouvoir() {


    }
}

