package modele;
import controleur.Interaction;
import java.util.Random;
public class Assassin extends Personnage {

    // Constructeur par défaut
    public Assassin() {
        // Appelle le constructeur de la classe mère avec des valeurs par défaut
        super("Assassin", 1, Caracteristiques.ASSASSIN);
    }

    @Override
    public void utiliserPouvoir() {
        // Affiche tous les personnages du jeu
        System.out.println("Personnages du jeu : ");

        for (int i = 0; i < getPlateau().getNombrePersonnages(); i++) {
            Personnage personnage = getPlateau().getPersonnage(i);
            System.out.println((i + 1) + " " + personnage.getNom());
        }

        int choix;

        do {
            // Demande à l'utilisateur quel personnage assassiner
            System.out.print("Quel personnage voulez-vous assassiner ? ");
            choix = Interaction.lireUnEntier();

            if (choix < 1 || choix > getPlateau().getNombrePersonnages()) {
                System.out.println("Personnage invalide. Veuillez choisir un numéro de personnage valide.");
            } else {
                Personnage personnage = getPlateau().getPersonnage(choix - 1);

                if (personnage.getNom().equals("Assassin")) {
                    System.out.println("Assassinat impossible sur soi-même. Veuillez choisir un autre personnage.");
                } else if (personnage.estHorsJeu()) {
                    System.out.println("Impossible d'assassiner un personnage hors jeu. Fin du pouvoir");

                } else {
                    personnage.setAssassine();
                    System.out.println("Le personnage " + personnage.getNom() + " a été assassiné.");
                }
            }

        } while ((choix < 1 || choix > getPlateau().getNombrePersonnages()) ||
                (choix > 0 && choix <= getPlateau().getNombrePersonnages() && getPlateau().getPersonnage(choix - 1).getRang() == 1));
    }

    @Override
    public void utiliserPouvoirAvatar() {
        // Affiche tous les personnages du jeu
        System.out.println("Personnages du jeu : ");

        for (int i = 0; i < getPlateau().getNombrePersonnages(); i++) {
            Personnage personnage = getPlateau().getPersonnage(i);
            System.out.println((i + 1) + " " + personnage.getNom());
        }

        // Utilisation d'un choix aléatoire pour simuler le personnage à assassiner
        Random random = new Random();
        int choix;

        do {
            choix = random.nextInt(getPlateau().getNombrePersonnages()) + 1;
            Personnage personnage = getPlateau().getPersonnage(choix - 1);

            // Vérifie que le joueur ne peut pas se choisir lui-même
            if (!personnage.getNom().equals("Assassin")) {
                personnage.setAssassine();
                System.out.println("Le personnage " + personnage.getNom() + " a été assassiné.");
            }

        } while (getPlateau().getPersonnage(choix - 1).getNom().equals("Assassin"));
    }
    }

