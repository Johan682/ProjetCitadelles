package modele;

import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Scanner;

public class Magicienne extends Personnage {

    // Constructeur par défaut
    public Magicienne() {
        // Appelle le constructeur de la classe mère avec des valeurs par défaut
        super("Magicienne", 3, Caracteristiques.MAGICIENNE);
    }

    public void utiliserPouvoir() {
        Scanner scanner = new Scanner(System.in);

        try {
            // Vérifier si le joueur a des cartes dans sa main
            if (getJoueur().nbQuartiersDansMain() == 0) {
                System.out.println("Vous n'avez pas de cartes dans votre main.");
                return;
            }

            // Demander à l'utilisateur s'il veut échanger toutes ses cartes avec un autre joueur
            System.out.print("Voulez-vous échanger toutes vos cartes avec celles d'un autre joueur ? (o/n) ");
            char choixEchange = scanner.next().charAt(0);

            if (Character.toLowerCase(choixEchange) == 'o') {
                // Afficher tous les joueurs et le nombre de cartes dans leur main
                System.out.println("Joueurs disponibles : ");
                for (int i = 0; i < getPlateau().getNombreJoueurs(); i++) {
                    Joueur joueur = getPlateau().getJoueur(i);
                    System.out.println((i + 1) + ". " + joueur.getPersonnage().getNom() + "(" + joueur.getNom() + ") - Cartes : " + joueur.nbQuartiersDansMain());
                }

                // Demander à l'utilisateur de choisir un joueur (la Magicienne ne peut pas se choisir elle-même)
                int choixJoueur;
                do {
                    System.out.print("Choisissez un joueur (entrez le numéro) : ");
                    choixJoueur = scanner.nextInt();

                    if (choixJoueur > 0 && choixJoueur <= getPlateau().getNombreJoueurs() &&
                            getPlateau().getPersonnage(choixJoueur - 1) instanceof Magicienne) {
                        System.out.println("Impossible de se choisir soi-même.");
                    }
                } while (choixJoueur < 1 || choixJoueur > getPlateau().getNombreJoueurs() ||
                        getPlateau().getPersonnage(choixJoueur - 1) instanceof Magicienne);

                Joueur joueurChoisi = getPlateau().getJoueur(choixJoueur - 1);

                // Échanger toutes les cartes
                echangeToutesCartes(joueurChoisi);
            } else if (Character.toLowerCase(choixEchange) == 'n') {
                // Si l'utilisateur ne souhaite pas échanger, demander combien de cartes il veut piocher
                int nbCartesPioche;
                do {
                    System.out.print("Combien de cartes souhaitez-vous piocher ?  : ");
                    nbCartesPioche = scanner.nextInt();

                    if (nbCartesPioche < 0 || nbCartesPioche > getJoueur().nbQuartiersDansMain()) {
                        System.out.println("Veuillez entrer un nombre valide (entre 0 : ne rien faire et votre nombre de cartes) ");
                    }
                } while (nbCartesPioche < 0 || nbCartesPioche > getJoueur().nbQuartiersDansMain());

                // Piocher le nombre de cartes demandé
                piocherCartes(nbCartesPioche);
            } else {
                // Si la réponse n'est ni 'o' ni 'n', afficher un message d'erreur
                System.out.println("Réponse non valide. Fin du pouvoir");
            }
        } catch (InputMismatchException e) {
            // Capture l'exception liée à une saisie invalide (non char)
            System.out.println("Réponse invalide. Fin du pouvoir");
        }
    }

    private void piocherCartes(int nbCartes) {
        Scanner scanner = new Scanner(System.in);

        // Vérifier si le nombre de cartes à piocher est zéro
        if (nbCartes == 0) {
            System.out.println("Aucune carte piochée.");
            return;  // Sortir de la méthode si aucun carte n'est piochée
        }

        for (int h = 0; h < nbCartes; h++) {
            // Demander à l'utilisateur quelle carte il veut défausser
            int choixDefausse;
            do {
                // Afficher les cartes actuelles dans la main de la Magicienne
                System.out.println("Voici vos cartes actuelles : ");
                ArrayList<Quartier> mainMagicienne = getJoueur().getMain();
                for (int i = 0; i < mainMagicienne.size(); i++) {
                    Quartier carte = mainMagicienne.get(i);
                    System.out.println((i + 1) + ". " + carte.getNom() + " - Type : " + carte.getType() + " - Pièces : " + carte.getCout());
                }

                System.out.print("Quelle carte souhaitez-vous défausser avant de piocher ? (entrez le numéro, 0 pour ne rien défausser) : ");
                choixDefausse = scanner.nextInt();

                if (choixDefausse < 0 || choixDefausse > getJoueur().nbQuartiersDansMain()) {
                    System.out.println("Numéro de carte invalide. Veuillez choisir un numéro de carte valide.");
                }
            } while (choixDefausse < 0 || choixDefausse > getJoueur().nbQuartiersDansMain());

            // Défausser la carte choisie
            if (choixDefausse != 0) {
                Quartier carteDefaussee = getJoueur().retirerQuartierDansMain();
                System.out.println("Vous avez défaussé la carte : " + carteDefaussee.getNom());

                // Ajouter la carte défaussée à la pioche
                getPlateau().getPioche().ajouter(carteDefaussee);

                System.out.println("Défausse de carte effectuée avec succès.");
            } else {
                System.out.println("Aucune carte défaussée.");
            }

            // Piocher une carte de la pioche
            Quartier cartePioche = getPlateau().getPioche().piocher();
            // Ajouter la carte piochée à la main de la Magicienne
            getJoueur().ajouterQuartierDansMain(cartePioche);
            System.out.println("Vous avez pioché la carte : " + cartePioche.getNom());
        }
    }

    private void echangeToutesCartes(Joueur joueur) {
        // Faire une copie des mains
        ArrayList<Quartier> copieMainMagicienne = new ArrayList<>(getJoueur().getMain());
        ArrayList<Quartier> copieMainJoueur = new ArrayList<>(joueur.getMain());

        // Vider la main originale du joueur
        joueur.getMain().clear();

        // Ajouter toutes les cartes de la copie dans la main originale du joueur
        joueur.getMain().addAll(copieMainMagicienne);

        // Vider la main de la Magicienne
        getJoueur().getMain().clear();

        // Ajouter toutes les cartes de la copie dans la main de la Magicienne
        getJoueur().getMain().addAll(copieMainJoueur);

        System.out.println("Échange de toutes les cartes effectué avec succès.");
    }
}
