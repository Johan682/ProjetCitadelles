package modele;

public class Architecte extends Personnage {

    private int constructionsRestantes; // Pour suivre le nombre de constructions restantes

    // Constructeur par défaut
    public Architecte() {
        // Appelle le constructeur de la classe mère avec des valeurs par défaut
        super("Architecte", 7, Caracteristiques.ARCHITECTE);
        constructionsRestantes = 3; // L'architecte peut initialement construire jusqu'à 3 quartiers par tour
    }

    public void utiliserPouvoir() {
            int nombreCartesPioche = 2;
            for (int i = 0; i < nombreCartesPioche; i++) {
                Quartier cartePiochee = getPlateau().getPioche().piocher();
                if (cartePiochee != null) {
                    getJoueur().ajouterQuartierDansMain(cartePiochee);
                }
            }
        }
    }

