package modele;

public class Espion extends Personnage {




    public Espion() {
        // Appelle le constructeur de la classe mère avec des valeurs par défaut
        super("Espion", 2, Caracteristiques.ESPION);

    }
    @Override
    public void utiliserPouvoir() {

    }
}

