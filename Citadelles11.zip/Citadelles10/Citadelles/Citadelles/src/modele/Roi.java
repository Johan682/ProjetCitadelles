package modele;

    public class Roi extends Personnage {

        public Roi() {
            super("Roi", 4, Caracteristiques.ROI);
        }

        @Override
        public void utiliserPouvoir() {
            if (getJoueur() != null && !getAssassine()) {
            System.out.println("Je prends la couronne");
                getJoueur().setPossedeCouronne(true);
            }
        }

        @Override
        public void utiliserPouvoirAvatar() {
            if (getJoueur() != null && !getAssassine()) {
                System.out.println("Je prends la couronne");
                getJoueur().setPossedeCouronne(true);
            }

        }
        @Override
        public void percevoirRessourcesSpecifiques() {
            int compteur = 0;
            if (getJoueur() != null && !getAssassine()) {
                for (Quartier unQuartier : getJoueur().getCite()) {
                    if (unQuartier != null && unQuartier.getType().equals("NOBLE")) {
                        compteur ++;
                    }
                }
                getJoueur().ajouterPieces(compteur);
            }
        }
    }


