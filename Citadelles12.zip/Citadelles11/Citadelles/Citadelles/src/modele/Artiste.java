package modele;

public class Artiste extends Personnage {
    public Artiste() {
        super("Artiste", 9, Caracteristiques.ARTISTE);
    }

    @Override
    public void utiliserPouvoir() {
        // Logique pour embellir un ou deux quartiers
        // ...
    }
}

