package modele;

public class PlateauDeJeu {
    private int nombreJoueurs ;
    private int nombrePersonnages;
    private Joueur[] listeJoueurs;
    private Personnage[] listePersonnages;
    private Pioche pioche;

    public PlateauDeJeu() {
        this.nombreJoueurs = 0;
        this.nombrePersonnages = 0;
        this.listeJoueurs = new Joueur[9];
        this.listePersonnages = new Personnage[9];
        this.pioche = new Pioche();
    }

    public int getNombrePersonnages() {
        return nombrePersonnages;
    }

    public int getNombreJoueurs() {
        return nombreJoueurs;
    }

    public Pioche getPioche() {
        return pioche;
    }

    public Personnage getPersonnage(int i) {
        if (i >= 0 && i < listePersonnages.length) {
            return listePersonnages[i];
        } else {
            return null;
        }
    }

    public Joueur getJoueur(int i) {
        if (i >= 0 && i < listeJoueurs.length) {
            return listeJoueurs[i];
        } else {
            return null;
        }
    }
    public void ajouterPersonnage(Personnage personnage) {
        if (personnage != null && nombrePersonnages < 9) {
            personnage.setPlateau(this);
            listePersonnages[nombrePersonnages] = personnage;
            nombrePersonnages++;
        }
    }
    public void ajouterJoueur(Joueur nouveauJoueur) {
        if (nouveauJoueur != null) {
            if (nombreJoueurs < 9) {
                listeJoueurs[nombreJoueurs] = nouveauJoueur;
                nombreJoueurs++;
            } else {
                System.out.println("Le tableau de joueurs est déjà plein.");
            }
        } else {
            System.out.println("Le joueur à ajouter ne peut pas être null.");
        }
    }
}
