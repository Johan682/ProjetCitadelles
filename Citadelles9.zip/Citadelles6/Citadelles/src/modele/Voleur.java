package modele;


import controleur.Interaction;
public class Voleur extends Personnage {

    // Constructeur par défaut
    public Voleur() {
        // Appelle le constructeur de la classe mère avec des valeurs par défaut
        super("Voleur", 2, Caracteristiques.VOLEUR);
    }

    @Override
    public void utiliserPouvoir() {
            // Affiche tous les personnages du jeu
            System.out.println("Personnages du jeu : ");

            for (int i = 0; i < getPlateau().getNombrePersonnages(); i++) {
                Personnage personnage = getPlateau().getPersonnage(i);
                System.out.println((i + 1) + " " + personnage.getNom());
            }

            int choix;
            int montantVole = 0;

            do {
                // Demande à l'utilisateur quel personnage vouloir voler
                System.out.print("Quel personnage voulez-vous voler ? ");
                choix = Interaction.lireUnEntier();

                // Vérifie que le joueur ne peut pas se choisir lui-même
                if (choix < 1 || choix > getPlateau().getNombrePersonnages()) {
                    System.out.println("Personnage invalide. Veuillez choisir un numéro de personnage valide.");
                } else {
                    // Modifie l'état du personnage choisi en fonction du rang
                    Personnage personnage = getPlateau().getPersonnage(choix - 1);

                    // Ajoute une condition pour empêcher le vol en fonction du rang
                    if (personnage.getNom().equals("Voleur")) {
                        System.out.println("Le voleur ne peut pas se voler tout seul. Veuillez choisir un autre personnage.");
                    } else if (personnage.getRang() == 1) {
                        System.out.println("Vol sur un personnage de rang 1 impossible");
                    } else {
                        // Vole intégralement le trésor du personnage choisi
                        montantVole = personnage.getJoueur().nbPieces();
                        personnage.setVole();
                        personnage.getJoueur().retirerPieces(montantVole);
                        getJoueur().ajouterPieces(montantVole);

                        // Affiche le résultat du vol
                        System.out.println("Le voleur a volé tout le trésor de " + personnage.getNom() + " (montant : " + montantVole + " pièces)");
                        System.out.println("Le voleur a maintenant " + getJoueur().nbPieces() + " pièces.");
                    }
                }
            } while ((choix < 1 || choix > getPlateau().getNombrePersonnages()) ||
                    (choix > 0 && choix <= getPlateau().getNombrePersonnages() && getPlateau().getPersonnage(choix - 1).getNom().equals("Voleur")) ||
                    (choix > 0 && choix <= getPlateau().getNombrePersonnages() && getPlateau().getPersonnage(choix - 1).getRang() == 1));
        }
    }
