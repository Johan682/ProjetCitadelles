package application;

import controleur.*;
import modele.*;

import java.util.Random;

public class Jeu {

    private PlateauDeJeu plateauDeJeu;
    private int numeroConfiguration;
    private Random generateur;
    private Joueur joueurCourant;

    // Constructor
    public Jeu() {
        plateauDeJeu = new PlateauDeJeu();
        numeroConfiguration = 0;
        generateur = new Random();
        joueurCourant = null;
    }

    // Public method to start the game
    public void jouer() {
        System.out.println("Bienvenue dans le jeu!");

        // Boucle du menu
        boolean continuer = true;
        while (continuer) {
            // Affichage du menu
            System.out.println("Menu:");
            System.out.println("1. Jouer");
            System.out.println("2. Afficher les règles");
            System.out.println("3. Quitter");

            // Saisie de l'utilisateur
            System.out.print("Choisissez une option (1, 2, ou 3) : ");
            int choix = Interaction.lireUnEntier();

            // Logique en fonction du choix
            switch (choix) {
                case 1:
                    jouerPartie();
                    break;
                case 2:
                    afficherLesRegles();
                    break;
                case 3:
                    continuer = false;
                    System.out.println("Merci d'avoir joué! Au revoir.");
                    break;
                default:
                    System.out.println("Option non valide. Veuillez choisir une option valide.");
                    break;
            }
        }
    }

    private void afficherLesRegles() {
        System.out.println("Les règles du jeu sont les suivantes...");
    }

    private void jouerPartie() {
        initialisation();

        // Boucle de jeu
        while (!partieFinie()) {
            tourDeJeu();
            gestionCouronne();
            reinitialisationPersonnages();
        }

        // Afficher les scores finaux
        calculDesPoints();
    }

    private void initialisation() {
        System.out.println("Initialisation de la partie...");

        // Utiliser la classe Configuration pour configurer le plateau de jeu
        plateauDeJeu = Configuration.configurationDeBase(new Pioche());

        // Distribuer deux pièces d'or et quatre cartes Quartier à chaque joueur
        for (int i = 0; i < plateauDeJeu.getNombreJoueurs(); i++) {
            Joueur joueur = plateauDeJeu.getJoueur(i);
            joueur.ajouterPieces(2);  // Distribuer deux pièces d'or
            joueur.ajouterQuartierDansMain(plateauDeJeu.getPioche().piocher());  // Distribuer quatre cartes Quartier
            joueur.ajouterQuartierDansMain(plateauDeJeu.getPioche().piocher());
            joueur.ajouterQuartierDansMain(plateauDeJeu.getPioche().piocher());
            joueur.ajouterQuartierDansMain(plateauDeJeu.getPioche().piocher());
        }

        afficherInformationsJoueurs();
        // Attribuer la couronne à l'un des joueurs pour le premier tour
        int numeroJoueurCouronne = generateur.nextInt(plateauDeJeu.getNombreJoueurs());
        joueurCourant = plateauDeJeu.getJoueur(numeroJoueurCouronne);  // Update the current player
        joueurCourant.setPossedeCouronne(true);
        System.out.println("La couronne est attribuée à " + joueurCourant.getNom() + ".");

        System.out.println("Initialisation terminée!");
    }

    private void afficherInformationsJoueurs() {
        System.out.println("Informations des joueurs :");
        for (int i = 0; i < plateauDeJeu.getNombreJoueurs(); i++) {
            Joueur joueur = plateauDeJeu.getJoueur(i);
            System.out.println(joueur.getNom() + " - Pièces : " + joueur.nbPieces() +
                    ", Cartes en main : " + joueur.nbQuartiersDansMain());
        }
        System.out.println();  // Ligne vide pour la clarté
    }

    private void gestionCouronne() {
        // Add crown management logic here
    }

    private void reinitialisationPersonnages() {
        // Add character reset logic here
    }

    private boolean partieFinie() {
        // Placeholder, return true for now
        return false;
    }

    private void tourDeJeu() {
        choixPersonnages();
        traiterActionsPersonnage();
        reinitialiserecarter();
    }

    public void choixPersonnages() {
        System.out.println("Choix des personnages :");

        // Écarter 2 cartes face visible
        ecarterCarteFaceVisible();
        ecarterCarteFaceVisible();
        // Écarter 2 cartes face cachée
        ecarterCarteFaceCachee();
        ecarterCarteFaceCachee();

        // Afficher les personnages restants à choisir
        afficherPersonnagesRestants();

        // Seul le joueur avec la couronne choisit en premier
        choixPersonnagePourJoueur(joueurCourant);

        // Les autres joueurs choisissent à leur tour
        for (int i = 0; i < plateauDeJeu.getNombreJoueurs(); i++) {
            Joueur joueur = plateauDeJeu.getJoueur(i);
            if (!joueur.getPossedeCouronne()) {
                choixPersonnagePourJoueur(joueur);
            }
        }

        // Réinitialiser l'état horsJeu uniquement pour les personnages assignés à des joueurs
        for (int i = 0; i < plateauDeJeu.getNombrePersonnages(); i++) {
            Personnage personnage = plateauDeJeu.getPersonnage(i);
            if (personnage != null && personnage.getJoueur() != null) {
                personnage.pashorsjeu();
            }
        }
    }



    private void reinitialiserecarter() {
        for (int i = 0; i < plateauDeJeu.getNombrePersonnages(); i++) {
            Personnage personnage = plateauDeJeu.getPersonnage(i);

                personnage.pashorsjeu();

            }
        }


    private void ecarterCarteFaceVisible() {
        // Sélectionner un personnage au hasard
        Personnage personnageCible;

        do {
            personnageCible = plateauDeJeu.getPersonnage(generateur.nextInt(plateauDeJeu.getNombrePersonnages()));
        } while (personnageCible.estHorsJeu() || personnageCible.getNom().equals("Roi"));
        // Répéter tant que le personnage est déjà hors jeu ou est le Roi

        // Écarter le personnage face visible
        personnageCible.mettreHorsJeu();
        System.out.println("Le personnage " + personnageCible.getNom() + " a été écarté du jeu");
    }

    private void ecarterCarteFaceCachee() {
        // Sélectionner un personnage au hasard
        Personnage personnageCible;

        do {
            personnageCible = plateauDeJeu.getPersonnage(generateur.nextInt(plateauDeJeu.getNombrePersonnages()));
        } while (personnageCible.estHorsJeu());  // Répéter tant que le personnage est déjà hors jeu

        // Écarter le personnage face cachée
        personnageCible.mettreHorsJeu();
        System.out.println("Un personnage a été écarté du jeu");
    }

    private void afficherPersonnagesRestants() {
        System.out.println("Personnages restants à choisir :");

        for (int i = 0; i < plateauDeJeu.getNombrePersonnages(); i++) {
            Personnage personnage = plateauDeJeu.getPersonnage(i);
            if (personnage != null && !personnage.estHorsJeu()) {
                System.out.println(personnage.getRang() - 1 + "-" + personnage.getNom());
            }
        }
    }

    private void choixPersonnagePourJoueur(Joueur joueur) {
        System.out.println(joueur.getNom() + ", c'est votre tour de choisir un personnage.");
        afficherPersonnagesRestants();

        // Lire le choix du joueur
        int choix = Interaction.lireUnEntier();

        // Vérifier si le personnage choisi est valide
        while (choix < 0 || choix >= plateauDeJeu.getNombrePersonnages() || plateauDeJeu.getPersonnage(choix).estHorsJeu()) {
            System.out.println("Choix invalide. Veuillez choisir un personnage valide.");
            afficherPersonnagesRestants();
            choix = Interaction.lireUnEntier();
        }

        // Le choix est valide, attribuer le personnage au joueur
        Personnage personnageChoisi = plateauDeJeu.getPersonnage(choix);
        personnageChoisi.setJoueur(joueur);
        System.out.println(joueur.getNom() + " a choisi le personnage " + personnageChoisi.getNom());
        personnageChoisi.mettreHorsJeu();  // Écarter le personnage choisi de la liste affichage
    }

    private void percevoirRessource() {
        // Add resource perception logic here
    }

    private void calculDesPoints() {
        // Add point calculation logic here
    }

    private void traiterActionsPersonnage() {
        System.out.println("Traitement des actions des personnages :");

        for (int i = 0; i < plateauDeJeu.getNombrePersonnages(); i++) {
            Personnage personnage = plateauDeJeu.getPersonnage(i);
            if (personnage != null && personnage.getJoueur() != null) {
                System.out.println("C'est au tour de " + personnage.getJoueur().getNom() + " avec le personnage " + personnage.getNom());

                if (!personnage.getAssassine()) {
                    // Si le personnage n'est pas assassiné, le joueur peut effectuer des actions
                    if (personnage.getVole()) {
                        // Si le personnage est voleur, prendre tout l'argent de la cible
                        System.out.println("Gestion Vol");

                    }

                    // Percevoir les ressources générales
                    percevoirRessourceGenerale(personnage);

                    // Percevoir les ressources spécifiques liées au pouvoir du personnage
                    percevoirRessourceSpecifique(personnage);

                    // Utiliser le pouvoir du personnage
                    utiliserPouvoirPersonnage(personnage);
                } else {
                    // Si le personnage est assassiné, ne rien faire
                    System.out.println("Le personnage " + personnage.getNom() + " est assassiné et ne peut pas agir.");
                }
            }
        }
    }

    private void percevoirRessourceGenerale(Personnage personnage) {
        // Logique pour percevoir les ressources générales (cartes ou pièces d'or)
        // ...

        System.out.println(personnage.getJoueur().getNom() + " perçoit des ressources générales.");
    }

    private void percevoirRessourceSpecifique(Personnage personnage) {
        // Logique pour percevoir les ressources spécifiques liées au pouvoir du personnage
        // ...

        System.out.println(personnage.getJoueur().getNom() + " perçoit des ressources spécifiques liées à son pouvoir.");
    }

    private void utiliserPouvoirPersonnage(Personnage personnage) {

        personnage.utiliserPouvoir();

        System.out.println(personnage.getJoueur().getNom() + " utilise le pouvoir de " + personnage.getNom() + ".");
    }
}
