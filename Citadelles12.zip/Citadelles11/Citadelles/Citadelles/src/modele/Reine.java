package modele;

public class Reine extends Personnage {
    public Reine() {
        super("Reine", 9, Caracteristiques.REINE);
    }

    @Override
    public void utiliserPouvoir() {
        // Logique pour recevoir 3 pi�ces d'or si le joueur � c�t� a choisi un personnage de rang 4
        // ...
    }
}
