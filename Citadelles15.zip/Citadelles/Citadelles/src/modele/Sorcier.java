package modele;

public class Sorcier extends Personnage {




    public Sorcier() {
        // Appelle le constructeur de la classe mère avec des valeurs par défaut
        super("Sorcier", 7, Caracteristiques.SORCIER);

    }
    @Override
    public void utiliserPouvoir() {

    }
}

