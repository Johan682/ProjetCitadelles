package modele;

import java.util.Random;

public class Architecte extends Personnage {

    private int constructionsRestantes; // Pour suivre le nombre de constructions restantes

    // Constructeur par défaut
    public Architecte() {
        // Appelle le constructeur de la classe mère avec des valeurs par défaut
        super("Architecte", 7, Caracteristiques.ARCHITECTE);
        constructionsRestantes = 3; // L'architecte peut initialement construire jusqu'à 3 quartiers par tour
    }

    public void utiliserPouvoir() {
            int nombreCartesPioche = 2;
            for (int i = 0; i < nombreCartesPioche; i++) {
                Quartier cartePiochee = getPlateau().getPioche().piocher();
                if (cartePiochee != null) {
                    getJoueur().ajouterQuartierDansMain(cartePiochee);
                }
            }
        }
    @Override
    public void utiliserPouvoirAvatar() {
        Random random = new Random();

        // Simuler le pouvoir de l'architecte pour piocher deux cartes quartier supplémentaires
        int nombreCartesPioche = 2;
        for (int i = 0; i < nombreCartesPioche; i++) {
            Quartier cartePiochee = getPlateau().getPioche().piocher();
            if (cartePiochee != null) {
                getJoueur().ajouterQuartierDansMain(cartePiochee);
            }
        }

        // Simuler la construction de quartiers (choix aléatoire)
        while (constructionsRestantes > 0) {
            // Supposons que vous avez une liste de quartiers dans la main du joueur
            int indexQuartier = random.nextInt(getJoueur().nbQuartiersDansMain());
            Quartier quartierAConstruire = getJoueur().getMain().get(indexQuartier);

            // Simuler la construction du quartier
            getJoueur().ajouterQuartierDansCite(quartierAConstruire);

            // Décrémenter le nombre de constructions restantes
            constructionsRestantes--;
        }
    }
    }

