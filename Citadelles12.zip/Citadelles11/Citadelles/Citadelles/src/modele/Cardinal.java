package modele;

public class Cardinal extends Personnage {
    public Cardinal() {
        super("Cardinal", 5, Caracteristiques.CARDINAL);
    }

    @Override
    public void utiliserPouvoir() {



    }
}

