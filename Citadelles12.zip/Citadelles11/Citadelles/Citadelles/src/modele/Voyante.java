package modele;

public class Voyante extends Personnage {
    public Voyante() {
        super("Voyante", 3, Caracteristiques.VOYANTE);
    }

    @Override
    public void utiliserPouvoir() {
        System.out.println("Prenez 1 carte au hasard de la main de chaque autre joueur, et ajoutez ces cartes � la v�tre.");
        // Impl�mentez la logique pour prendre et redistribuer les cartes
        // ...

        System.out.println("Vous avez utilis� le pouvoir de la Voyante.");
    }
}
