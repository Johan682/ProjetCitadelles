package modele;

public class Empereur extends Personnage {
    public Empereur() {
        super("Empereur", 4, Caracteristiques.EMPEREUR);
    }

    @Override
    public void utiliserPouvoir() {


    }
}
