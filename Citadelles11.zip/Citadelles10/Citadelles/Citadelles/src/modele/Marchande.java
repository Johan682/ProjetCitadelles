package modele;

import java.util.Random;
import java.util.Scanner;

public class Marchande extends Personnage {

    // Constructeur par défaut
    public Marchande() {
        // Appelle le constructeur de la classe mère avec des valeurs par défaut
        super("Marchande", 6, Caracteristiques.MARCHANDE);
    }

    public void utiliserPouvoir() {
            getJoueur().ajouterPieces(1);
    }

    @Override
    public void utiliserPouvoirAvatar() {
        Random random = new Random();

        // L'ordinateur décide s'il veut utiliser le pouvoir
        boolean utiliserPouvoir = random.nextBoolean();

        if (utiliserPouvoir) {
            if (getAssassine() || getVole()) {
                System.out.println("Vous ne pouvez pas jouer votre tour");
            } else {
                //Une pièce ajoutée à chaque tour
                getJoueur().ajouterPieces(1);
            }
        }else{
            System.out.println("L'ordinateur ne veut pas utiliser le pouvoir du personnage");
        }

    }

    @Override
    public void percevoirRessourcesSpecifiques() {

            int compteur = 0;
            if (!getAssassine()) {
                for (Quartier unQuartier : getJoueur().getCite()) {
                    if (unQuartier != null && unQuartier.getType().equals("COMMERCANT")) {
                        compteur++;
                    }
                }
                getJoueur().ajouterPieces(compteur);
            }
        }
    }

