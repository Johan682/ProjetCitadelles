package modele;

import java.util.Scanner;

public class Marchande extends Personnage {

    // Constructeur par défaut
    public Marchande() {
        // Appelle le constructeur de la classe mère avec des valeurs par défaut
        super("Marchande", 6, Caracteristiques.MARCHANDE);
    }

    public void utiliserPouvoir() {

            getJoueur().ajouterPieces(1);

    }

    @Override
    public void percevoirRessourcesSpecifiques() {

            int compteur = 0;
            if (getAssassine() != true) {
                for (Quartier unQuartier : getJoueur().getCite()) {
                    if (unQuartier != null && unQuartier.getType().equals("COMMERCANT")) {
                        compteur++;
                    }
                }
                getJoueur().ajouterPieces(compteur);
            }
        }
    }

