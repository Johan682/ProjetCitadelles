package modele;

import controleur.Interaction;

public class Espion extends Personnage {
    public Espion() {
        super("Espion", 2, Caracteristiques.ESPION);
    }

    @Override
    public void utiliserPouvoir() {
        System.out.println("D�signez un autre joueur et choisissez un type quartier.");
        // Lisez le joueur cibl� et le type de quartier
        int joueurCible = Interaction.lireUnEntier();
        String typeQuartier = Interaction.lireUneChaine();

        // Impl�mentez la logique pour regarder les cartes du joueur cibl�
        // ...

        System.out.println("Vous avez regard� les cartes du joueur cibl�.");
    }
}

