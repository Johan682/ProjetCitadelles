package modele;

import java.util.Random;
import java.util.Scanner;

public class Condottiere extends Personnage {

    // Constructeur par défaut
    public Condottiere() {
        // Appelle le constructeur de la classe mère avec des valeurs par défaut
        super("Condottiere", 8, Caracteristiques.CONDOTTIERE);
    }

    @Override
    public void utiliserPouvoir() {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Voulez-vous utiliser votre pouvoir de destruction ? (o/n) ");
        char choix = scanner.next().charAt(0);

        if (Character.toLowerCase(choix) == 'o') {
            int choixJoueur;
            do {
                afficherCitadelles(); // Affiche les citadelles de tous les joueurs

                System.out.print("Quel joueur choisissez-vous ? (0 pour ne rien faire) ");
                while (!scanner.hasNextInt()) {
                    System.out.println("Invalide. Veuillez entrer un nombre valide.");
                    scanner.next(); // Clear the invalid input
                }
                choixJoueur = scanner.nextInt();

                if (choixJoueur >= 0 && choixJoueur <= getPlateau().getNombreJoueurs()) {
                    if (choixJoueur == 0) {
                        System.out.println("Vous avez choisi de ne rien faire.");
                        return;
                    }

                    Joueur joueurChoisi = getPlateau().getJoueur(choixJoueur - 1);

                    // Vérifier si le personnage du joueur choisi est de rang 6
                    if (joueurChoisi.getPersonnage().getNom().equals("Eveque")) {
                        System.out.println("Vous ne pouvez pas détruire les quartiers d'un eveque");
                        return;
                    }

                    // Afficher la liste des quartiers dans la cité du joueur choisi
                    System.out.println("Voici la liste des quartiers dans la cité de " + joueurChoisi.getNom() + " :");
                    afficherQuartiers(joueurChoisi.getCite());

                    int choixQuartier;
                    do {
                        System.out.print("Quel quartier choisissez-vous ? ");
                        while (!scanner.hasNextInt()) {
                            System.out.println("Choix invalide. Veuillez entrer un nombre valide.");
                            scanner.next(); // Clear the invalid input
                        }
                        choixQuartier = scanner.nextInt();

                        if (choixQuartier < 1 || choixQuartier > joueurChoisi.getCite().length || joueurChoisi.getCite()[choixQuartier - 1] == null) {
                            System.out.println("Choix de quartier invalide. Veuillez réessayer.");
                        }
                    } while (choixQuartier < 1 || choixQuartier > joueurChoisi.getCite().length || joueurChoisi.getCite()[choixQuartier - 1] == null);

                    Quartier quartierChoisi = joueurChoisi.getCite()[choixQuartier - 1];
                    int coutDestruction = quartierChoisi.getCout();

                    if (getJoueur().nbPieces() >= coutDestruction) {
                        getJoueur().retirerPieces(coutDestruction);
                        joueurChoisi.retirerQuartierDansCite(quartierChoisi.getNom());

                        System.out.println("Vous avez détruit le quartier " + quartierChoisi.getNom() + " de " + joueurChoisi.getNom() + ".");
                        break;
                    } else {
                        System.out.println("Votre trésor n'est pas suffisant pour détruire ce quartier. Fin du pouvoir.");
                        return; // Sortir de la méthode si le coût est trop élevé
                    }
                } else {
                    System.out.println("Choix invalide. Aucun quartier n'a été détruit.");
                }
            } while (true); // Boucle jusqu'à ce qu'un choix de joueur valide soit fait
        } else {
            System.out.println("Vous avez choisi de ne rien faire.");
        }
    }

    @Override
    public void utiliserPouvoirAvatar() {
        Random random = new Random();

        // L'ordinateur décide s'il veut utiliser le pouvoir
        boolean utiliserPouvoir = random.nextBoolean();

        if (utiliserPouvoir) {
            afficherCitadelles();

            // L'ordinateur choisit aléatoirement un joueur
            int choixJoueur = random.nextInt(getPlateau().getNombreJoueurs()) + 1;

            Joueur joueurChoisi = getPlateau().getJoueur(choixJoueur - 1);

            // Vérifier si le personnage du joueur choisi est de rang 6
            if (joueurChoisi.getPersonnage().getNom().equals("Eveque")) {
                System.out.println("L'ordinateur ne peut pas détruire les quartiers d'un eveque");
                return;
            }

            // L'ordinateur choisit aléatoirement un quartier
            int choixQuartier = random.nextInt(joueurChoisi.getCite().length) + 1;

            Quartier quartierChoisi = joueurChoisi.getCite()[choixQuartier - 1];

            int coutDestruction = quartierChoisi.getCout();

            if (getJoueur().nbPieces() >= coutDestruction) {
                getJoueur().retirerPieces(coutDestruction);
                joueurChoisi.retirerQuartierDansCite(quartierChoisi.getNom());

                System.out.println("L'ordinateur a détruit le quartier " + quartierChoisi.getNom() + " de " + joueurChoisi.getNom() + ".");
            } else {
                System.out.println("Le trésor de l'ordinateur n'est pas suffisant pour détruire ce quartier.");
            }
        } else {
            System.out.println("L'ordinateur a choisi de ne rien faire.");
        }
    }
    private void afficherCitadelles() {
        System.out.println("Voici les citadelles des joueurs :");
        for (int i = 0; i < getPlateau().getNombreJoueurs(); i++) {
            Joueur joueur = getPlateau().getJoueur(i);
            System.out.println((i + 1) + " " + joueur.getNom() + " (" + joueur.getPersonnage().getNom()+ ") :");
            afficherQuartiers(joueur.getCite());
        }
    }

    private void afficherQuartiers(Quartier[] citadelle) {
        for (int i = 0; i < citadelle.length; i++) {
            if (citadelle[i] != null) {
                System.out.println((i + 1) + " " + citadelle[i].getNom() + "(coût " + citadelle[i].getCout() + ")");
            }
        }
    }

    @Override
    public void percevoirRessourcesSpecifiques() {
        int compteur = 0;
        if (!getAssassine()) {
            for (Quartier unQuartier : getJoueur().getCite()) {
                if (unQuartier != null && "MILITAIRE".equals(unQuartier.getType())) {
                    compteur++;
                }
            }
            getJoueur().ajouterPieces(compteur);
        }
    }

}
