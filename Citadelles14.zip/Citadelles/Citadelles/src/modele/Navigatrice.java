package modele;

public class Navigatrice extends Personnage {

    public Navigatrice() {
        // Appelle le constructeur de la classe mère avec des valeurs par défaut
        super("Navigatrice", 7, Caracteristiques.NAVIGATRICE);

    }
    @Override
    public void utiliserPouvoir() {

    }
}

