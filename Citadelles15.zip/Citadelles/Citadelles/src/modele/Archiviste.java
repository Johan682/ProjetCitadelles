package modele;

public class Archiviste extends Personnage {




    public Archiviste() {
        // Appelle le constructeur de la classe mère avec des valeurs par défaut
        super("Archiviste", 7, Caracteristiques.ARCHIVISTE);

    }
    @Override
    public void utiliserPouvoir() {

    }
}

