package modele;

public class Bailli extends Personnage {
    public Bailli() {
        super("Bailli", 9, Caracteristiques.BAILLI);
    }

    @Override
    public void utiliserPouvoir() {
        // Logique pour payer la taxe lors de la construction d'un quartier
        // ...

        // Logique pour prendre tout l'or du jeton Bailli � n'importe quel moment
        // ...
    }
}

